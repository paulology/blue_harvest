/* 
 * Demo by http://creative-punch.net
 */

$(document).ready(function() {

    window.onload = function() {
        var navLine = false;
        var items = document.querySelectorAll('.circle a');

        for(var i = 0, l = items.length; i < l; i++) {
            items[i].style.left = (50 - 35*Math.cos(-0.5 * Math.PI - 2*(1/l)*(i-2)*Math.PI)).toFixed(4) + "%";
            items[i].style.top = (50 + 35*Math.sin(-0.5 * Math.PI - 2*(1/l)*(i-2)*Math.PI)).toFixed(4) + "%";
        }

        document.querySelector('.menu-button').onclick = function(e) {
            if (!navLine) {
                e.preventDefault();
                document.querySelector('.circle').classList.toggle('open');  
            } else {
                e.preventDefault();
                for(var i = 0, l = items.length; i < l; i++) {
                    var tInt = (50 + 35*Math.sin(-0.5 * Math.PI - 2*(1/l)*(i-2)*Math.PI)).toFixed(4);
                    var lInt = (50 - 35*Math.cos(-0.5 * Math.PI - 2*(1/l)*(i-2)*Math.PI)).toFixed(4);
                    var tString = tInt + "%";
                    var lString = lInt + "%";
                    $(items[i]).animate({top: tString, left: lString}, 400);
                }
                document.querySelector('.menu-button').classList.toggle('down');
                navLine = false;
            }
  
        };

        document.querySelector('.circle a').onclick = function(evt) {
            var lInt = (50 - 35*Math.cos(-0.5 * Math.PI - 2*(1/l)*(0-2)*Math.PI)).toFixed(4);
            var lString = lInt + "%";
            var count = 1;
            var times = 1;
            for(var i=items.length-1; i > 0; i--) {
                evt.preventDefault();
                var tInt = ((50 + 35*Math.sin(-0.5 * Math.PI - 2*(1/l)*(0-2)*Math.PI))+(29.7879*times)).toFixed(4);
                var tString = tInt + "%";
                $(items[i]).animate({left: lString, top: tString}, 100);
                for(var j=i-1; j>0; j--) {
                    var tInt2 = ((50 + 35*Math.sin(-0.5 * Math.PI - 2*(1/l)*(j-count)*Math.PI))+(29.7879*times)).toFixed(4);
                    var lInt2 = (50 - 35*Math.cos(-0.5 * Math.PI - 2*(1/l)*(j-count)*Math.PI)).toFixed(4);
                    var tString2 = tInt2 + "%";
                    var lString2 = lInt2 + "%";
                    $(items[j]).animate({left: lString2, top: tString2}, 100);
                }
                count--;
                times++;
            }
            if (!navLine) {
                document.querySelector('.menu-button').classList.toggle('down');
                navLine = true;
            }
        };
    };
});